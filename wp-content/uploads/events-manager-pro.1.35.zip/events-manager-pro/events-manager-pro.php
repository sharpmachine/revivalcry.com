<?php
/*
Plugin Name: Events Manager Pro
Plugin URI: http://wp-events-plugin.com
Description: Supercharge the Events Manager free plugin with extra feature to make your events even more successful! 
Author: NetWebLogic
Author URI: http://netweblogic.com/
Version: 1.35

Copyright (C) 2011 NetWebLogic LLC
*/
define('EMP_VERSION', 1.35);
define('EMP_SLUG', plugin_basename( __FILE__ ));
class EM_Pro {
	
	/**
	 * em_pro_data option
	 * @var array
	 */
	var $data;
		
	/**
	 * Class initialization
	 */
	function EM_Pro() {
		global $wpdb;
		//Set when to run the plugin : after EM is loaded.
		add_action( 'plugins_loaded', array(&$this,'init') );
		//Define some tables
		if( get_site_option('dbem_ms_global_table') ){
			$prefix = $wpdb->base_prefix;
		}else{
			$prefix = $wpdb->prefix;
		}		
		define('EM_TRANSACTIONS_TABLE', $prefix.'em_transactions'); //TABLE NAME
	}
	
	/**
	 * Actions to take upon initial action hook
	 */
	function init(){
		//Upgrade/Install Routine
		if( is_admin() && current_user_can('activate_plugins') ){
			$old_version = get_option('em_pro_version');
			if( EMP_VERSION > $old_version || $old_version == '' ){
				require_once(WP_PLUGIN_DIR.'/events-manager-pro/emp-install.php');
				emp_install();	
			}
		}
		//check that EM is installed
		if(!defined('EM_VERSION')){
			add_action('admin_notices',array(&$this,'em_install_warning'));
		}
		//include gateways
		include_once('gateways/class.gateway.php');
		include_once('gateways/gateway.paypal.php');
		include_once('gateways/gateway.offline.php');
		//booking form customization
		include_once('emp-bookings-form.php');
		add_action('wp_head', array(&$this,'wp_head'));
	}
	
	/**
	 * For now we'll just add style and js here 
	 */
	function wp_head(){
		?>
		<style type="text/css">
		 div.em-gateway-buttons { height:50px; width: 100%; }
		 div.em-gateway-buttons .first { padding-left:0px; margin-left:0px; border-left:none; }
		 div.em-gateway-button { float:left; padding-left:20px; margin-left:20px; border-left:1px solid #777; }
		</style>
		<?php
	}
	
	function em_install_warning(){
		?>
		<div class="error"><p><?php _e('Please make sure you install Events Manager as well. You can search and install this plugin from your plugin installer or download it <a href="http://wordpress.org/extend/plugins/events-manager/">here</a>.','em-pro'); ?></p></div> 
		<?php	
	}	
	
}
//Add translation
load_plugin_textdomain('em-pro', false, dirname( plugin_basename( __FILE__ ) ).'/langs'); 

//Include admin file if needed
if(is_admin()){
	//include_once('em-pro-admin.php');
	include_once('emp-updates.php'); //update manager
}

/* Creating the wp_events table to store event data*/
function emp_activate() {
	global $wp_rewrite;
   	$wp_rewrite->flush_rules();
}
register_activation_hook( __FILE__,'emp_activate');

// Start plugin
global $EM_Pro; 
$EM_Pro = new EM_Pro();

?>